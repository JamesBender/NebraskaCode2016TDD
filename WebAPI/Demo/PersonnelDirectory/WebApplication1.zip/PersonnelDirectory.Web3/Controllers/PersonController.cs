﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Routing;
using Microsoft.Data.OData.Metadata;
using PersonnelDirectory.Web.Models;
using PersonnelDirectory.Web.Models.ViewModels;

namespace PersonnelDirectory.Web.Controllers
{
    
    public class PersonController : ApiController
    {
        private readonly IPersonnelModel _personnelModel;

        public PersonController()
        {
            AutomapperConfiguration.Configure();
            _personnelModel = new PersonnelModel();
        }

        public IEnumerable<Person> Get()
        {
            return _personnelModel.GetAllPersonnel();
        }

        public Person GetPerson(int id)
        {
            var person = _personnelModel.GetPerson(id); //Int32.Parse(id));
            return person;
        }

        public int PostPerson(Person person)
        {
            return _personnelModel.SavePerson(person);
        }
    }
}
