﻿namespace PersonnelDirectory.Web.Models.ViewModels
{
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string Department { get; set; }
        public int UserId { get; set; }
    }
}